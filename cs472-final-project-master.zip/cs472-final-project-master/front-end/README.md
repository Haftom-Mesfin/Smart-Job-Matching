# INSTALLATION
* NodeJS LTS version

# RUNNING
* Go to front-end folder 
```
npm install
npm start
```
* localhost:3000