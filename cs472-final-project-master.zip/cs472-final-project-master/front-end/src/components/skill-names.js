const skillNames = [
    {
        value: 'HTML',
        label: 'HTML',
    },
    {
        value: 'CSS',
        label: 'CSS',
    },
    {
        value: 'Javascript',
        label: 'Javascript',
    },
    {
        value: 'NLP',
        label: 'NLP',
    },
    {
        value: 'Computer Vision',
        label: 'Computer Vision',
    },
    {
        value: 'Data visualization',
        label: 'Data visualization',
    },
    {
        value: 'jQuery',
        label: 'jQuery',
    },
    {
        value: 'Ajax & JSON',
        label: 'Ajax & JSON',
    },
    {
        value: 'MongoDB',
        label: 'MongoDB',
    },
    {
        value: 'MySQL',
        label: 'MySQL',
    },
    {
        value: 'Java',
        label: 'Java',
    },
    {
        value: 'Python',
        label: 'Python',
    },
    {
        value: 'R',
        label: 'R',
    },
    {
        value: 'Machine learning',
        label: 'Machine learning',
    },
    {
        value: 'Deep learning',
        label: 'Deep learning',
    }
]

export {skillNames}