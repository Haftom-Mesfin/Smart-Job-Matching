const yearOfExperience = [
    {
        value: '1-under-3',
        label: 'From 1 but below 3 years',
    },
    {
        value: '3-under-5',
        label: 'From 3 but below 5 years',
    },
    {
        value: '5-under-8',
        label: 'From 5 but below 8 years',
    },
    {
        value: 'from-8',
        label: 'From 8 years',
    },
]

export {yearOfExperience}