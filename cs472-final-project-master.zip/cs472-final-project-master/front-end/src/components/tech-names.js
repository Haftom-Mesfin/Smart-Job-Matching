const techNames = [
    {
        value: 'NodeJS',
        label: 'NodeJS',
    },
    {
        value: 'VueJS',
        label: 'VueJS',
    },
    {
        value: 'React',
        label: 'React',
    },
    {
        value: 'AngularJS',
        label: 'AngularJS',
    },
    {
        value: 'Spring Boot',
        label: 'Spring Boot',
    },
    {
        value: 'Django',
        label: 'Django',
    },
    {
        value: 'Numpy',
        label: 'Numpy',
    },
    {
        value: 'Pandas',
        label: 'Pandas',
    },
    {
        value: 'Tensorflow',
        label: 'Tensorflow',
    },
    {
        value: 'ExpressJS',
        label: 'ExpressJS',
    },
    {
        value: 'PyTorch',
        label: 'PyTorch',
    },
    {
        value: 'CNTK',
        label: 'CNTK',
    },
    {
        value: 'TFLearn',
        label: 'TFLearn',
    },
    {
        value: 'Scikit-Learn',
        label: 'Scikit-Learn',
    },
    {
        value: 'Keras',
        label: 'Keras',
    },
    {
        value: 'Ruby/Rails',
        label: 'Ruby/Rails',
    },
    {
        value: 'Flask',
        label: 'Flask',
    }
];

export {techNames}